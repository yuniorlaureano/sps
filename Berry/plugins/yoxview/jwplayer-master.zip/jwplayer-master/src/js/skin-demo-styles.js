define([
    'polyfill/eventlisteners',
    '../css/jwplayer.less'
], function () {
});