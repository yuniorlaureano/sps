define([], function() {
    return {
        repo : __REPO__,
        SkinsIncluded : ['seven'],
        SkinsLoadable : ['beelden', 'bekle', 'five', 'glow', 'roundster', 'six', 'stormtrooper', 'vapor'],
        dvrSeekLimit : -25
    };
});
