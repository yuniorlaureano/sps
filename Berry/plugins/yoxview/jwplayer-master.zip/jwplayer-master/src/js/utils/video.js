define([], function() {
    return document.createElement('video');
});
