define({
    tagged : {
        file : 'sample',
        type : 'flv'
    }
});
