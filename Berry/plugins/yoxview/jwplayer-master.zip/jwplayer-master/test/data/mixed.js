define({
    webm_mp4: {
        image: 'http://d3el35u4qe4frz.cloudfront.net/bkaovAYt-480.jpg',
        title: 'WebM and MP4',
        sources: [
            {
                file: 'http://content.bitsontherun.com/videos/bkaovAYt-27m5HpIu.webm'
            },
            {
                file: 'http://content.bitsontherun.com/videos/bkaovAYt-52qL9xLP.mp4'
            }
        ]
    },
    mp4_webm: {
        image: 'http://d3el35u4qe4frz.cloudfront.net/bkaovAYt-480.jpg',
        title: 'WebM and MP4',
        sources: [
            {
                file: 'http://content.bitsontherun.com/videos/bkaovAYt-52qL9xLP.mp4'
            },
            {
                file: 'http://content.bitsontherun.com/videos/bkaovAYt-27m5HpIu.webm'
            }
        ]
    }
});